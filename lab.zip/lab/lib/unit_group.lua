surface.create_unit_group {position, force}
