local tools = {}

tools.test_kit = {
    {name = "infinity-chest", count = 20}, {name = "infinity-pipe", count = 20},
    {name = "electric-energy-interface", count = 20},
    {name = "express-loader", count = 50},
    {name = "express-transport-belt", count = 50},
    {name = "express-underground-belt", count = 50},
    {name = "express-splitter", count = 50},
    {name = "stack-inserter", count = 50},
    {name = "medium-electric-pole", count = 50},
    {name = "big-electric-pole", count = 50}, {name = "substation", count = 50}
}

function tools.fixCoords(t, y)
    local flr = math.floor
    if y and type(t) == "number" then
        t = {
            x = t >= 0 and flr(t) + 0.5 or flr(t) - 0.5,
            y = y >= 0 and flr(y) + 0.5 or flr(y) - 0.5
        }
    elseif type(t) == "table" then
        t = {
            x = t[1] >= 0 and (flr(t[1]) + 0.5) or (flr(t[1]) - 0.5),
            y = t[2] >= 0 and (flr(t[2]) + 0.5) or (flr(t[2]) - 0.5)
        }
    end
    return t
end

function tools.makeCircle(radius, center)
    local results = {
        ["all"] = {},
        ["inside"] = {},
        ["cross"] = {},
        ["turrets"] = {},
        ["walls"] = {},
        ["belts"] = {}
    }
    local radius, radius_sq = (radius + 3), radius ^ 2
    local edge = radius * math.pi
    local center = center or game.player.position
    local sure = 0
    local area = {
        top_left = {x = center.x - radius, y = center.y - radius},
        bottom_right = {x = center.x + radius, y = center.y + radius}
    }
    for i = area.top_left.x, area.bottom_right.x, 1 do
        for j = area.top_left.y, area.bottom_right.y, 1 do
            local distance = math.floor((center.x - i) ^ 2 + (center.y - j) ^ 2)

            if ((distance < radius_sq) and (distance >= (radius_sq - (96 * 2)))) then
                table.insert(results["belts"], {
                    game.player.surface.create_entity {
                        name = "transport-belt",
                        position = tools.fixCoords({i, j}),
                        force = game.forces["neutral"]
                    }
                })
            end
        end
    end
    radius, radius_sq = (radius + 5), radius ^ 2
    area = {
        top_left = {x = center.x - radius, y = center.y - radius},
        bottom_right = {x = center.x + radius, y = center.y + radius}
    }
    for i = area.top_left.x, area.bottom_right.x, 2 do
        for j = area.top_left.y, area.bottom_right.y, 2 do
            distance = math.floor((center.x - i) ^ 2 + (center.y - j) ^ 2)

            if ((distance < radius_sq) and (distance >= (radius_sq - (96 * 3)))) then
                table.insert(results["turrets"], {
                    game.player.surface.create_entity {
                        name = "gun-turret",
                        position = tools.fixCoords({i, j}),
                        force = game.forces["neutral"]
                    }
                })
            end
        end
    end
    radius, radius_sq = (radius + 8), radius ^ 2
    area = {
        top_left = {x = center.x - radius, y = center.y - radius},
        bottom_right = {x = center.x + radius, y = center.y + radius}
    }
    for i = area.top_left.x, area.bottom_right.x, 1 do
        for j = area.top_left.y, area.bottom_right.y, 1 do
            distance = math.floor((center.x - i) ^ 2 + (center.y - j) ^ 2)

            if ((distance < radius_sq) and (distance >= (radius_sq - (96 * 2)))) then
                table.insert(results["walls"], {
                    game.player.surface.create_entity {
                        name = "stone-wall",
                        position = tools.fixCoords({i, j}),
                        force = game.forces["neutral"]
                    }
                })
            end

        end
    end
    game.player.surface.set_tiles(results.cross)
    for _, entity in pairs(results.walls) do
        table.insert(results.all, entity)
    end
    for _, entity in pairs(results.turrets) do
        table.insert(results.all, entity)
    end
    for _, entity in pairs(results.belts) do
        table.insert(results.all, entity)
    end
    game.player.force.chart(game.player.surface, area)
    return results
end

function tools.round(num, dp)
    local mult = 10 ^ (dp or 0)
    return math.floor(num * mult + 0.5) / mult
end

function tools.sortByValue(t)
    local keys = {}

    for key, _ in pairs(t) do table.insert(keys, key) end

    table.sort(keys, function(keyLhs, keyRhs) return t[keyLhs] < t[keyRhs] end)
    local r = {}
    for _, key in ipairs(keys) do table.insert(r, {[key] = t[key]}) end
    return r
end

function tools.createLabSurface()
    s = game.create_surface("lab")
    s.generate_with_lab_tiles, s.always_day = true
    return s
end

function tools.safeTeleport(player, surface, target_pos)
    local safe_pos = surface.find_non_colliding_position("character",
                                                         target_pos, 15, 1)
    if (not safe_pos) then
        player.teleport(target_pos, surface)
    else
        player.teleport(safe_pos, surface)
    end
end

function tools.givePowerArmorMK2(player)
    player.insert {name = "power-armor-mk2", count = 1}

    if player and player.get_inventory(defines.inventory.character_armor) ~= nil and
        player.get_inventory(defines.inventory.character_armor)[1] ~= nil then
        local p_armor =
            player.get_inventory(defines.inventory.character_armor)[1].grid
        if p_armor ~= nil then
            for i = 1, 2 do
                p_armor.put({name = "fusion-reactor-equipment"})
            end
            for i = 1, 2 do
                p_armor.put({name = "personal-laser-defense-equipment"})
            end
            for i = 1, 2 do
                p_armor.put({name = "exoskeleton-equipment"})
            end
            for i = 1, 2 do
                for j = 1, 2 do
                    p_armor.put({name = "personal-roboport-mk2-equipment"})
                end
                p_armor.put({name = "personal-laser-defense-equipment"})
            end
            for i = 1, 2 do
                p_armor.put({name = "energy-shield-mk2-equipment"})
            end
            for i = 1, 6 do
                p_armor.put({name = "battery-mk2-equipment"})
            end
        end
        player.insert {name = "construction-robot", count = 100}
        player.insert {name = "belt-immunity-equipment", count = 1}
    end
end

function tools.giveTestKit(player)
    for _, item in pairs(tools.test_kit) do player.insert(item) end
end

function tools.givePlayerLongReach(player)
    player.character.character_build_distance_bonus = 2500
    player.character.character_reach_distance_bonus = 2500
    player.character.character_resource_reach_distance_bonus = 2500
end

function tools.sel(n, ...) return arg[n] end

function tools.modules(moduleInventory) -- returns the multiplier of the modules
    local effect1 = moduleInventory.get_item_count("productivity-module") -- type 1
    local effect2 = moduleInventory.get_item_count("productivity-module-2") -- type 2
    local effect3 = moduleInventory.get_item_count("productivity-module-3") -- type 3

    local multi = effect1 * 4 + effect2 * 6 + effect3 * 10
    return multi / 100 + 1
end

function tools.amountOfMachines(itemsPerSecond, output)
    if (itemsPerSecond) then return itemsPerSecond / output end
end

commands.add_command("ratio",
                     "gives ratio info on the selected machine and its recipe. provide a number for items/sec",
                     function(command)
    local player = game.players[command.player_index]
    local machine = player.selected -- selected machine
    local itemsPerSecond
    if not machine then -- nil check
        return player.print("[color=red]No valid machine selected..[/color]")
    end

    if machine.type ~= "assembling-machine" and machine.type ~= "furnace" then
        return player.print("[color=red]Invalid machine..[/color]")
    end
    local recipe = machine.get_recipe() -- recipe

    if not recipe then -- nil check
        return player.print("[color=red]No recipe set..[/color]")
    end

    local items = recipe.ingredients -- items in that recipe
    local products = recipe.products -- output items
    local amountOfMachines
    local moduleInventory = machine.get_module_inventory() -- the module Inventory of the machine
    local multi = tools.modules(moduleInventory) -- function for the productively modules
    if (command.parameter ~= nil) then
        itemsPerSecond = tonumber(command.parameter)
    end
    if itemsPerSecond then
        amountOfMachines = math.ceil(tools.amountOfMachines(itemsPerSecond, 1 /
                                                                recipe.energy *
                                                                machine.crafting_speed *
                                                                products[1]
                                                                    .amount *
                                                                multi)) -- amount of machines
    end
    if not amountOfMachines then
        amountOfMachines = 1 -- set to 1 to make it not nil
    end
    ----------------------------items----------------------------
    for i, item in ipairs(items) do
        local sprite -- string to make the icon work either fluid ore item

        if item.type == "item" then
            sprite = 'ratio.item-in'
        else
            sprite = 'ratio.fluid-in'
        end

        local ips = item.amount / recipe.energy * machine.crafting_speed *
                        amountOfMachines -- math on the items/fluids per second
        player.print {sprite, tools.round(ips, 3), item.name} -- full string
    end
    ----------------------------products----------------------------

    for i, product in ipairs(products) do
        local sprite -- string to make the icon work either fluid ore item

        if product.type == "item" then
            sprite = 'ratio.item-out'
        else
            sprite = 'ratio.fluid-out'
        end

        local output = 1 / recipe.energy * machine.crafting_speed *
                           product.amount * multi -- math on the outputs per second
        player.print {
            sprite, tools.round(output * amountOfMachines, 3), product.name
        } -- full string

    end

    if amountOfMachines ~= 1 then
        player.print {'ratio.machines', amountOfMachines}
    end

end)

commands.add_command("get", "get item", function(command)
    local player = game.players[command.player_index]
    if game.item_prototypes[command.parameter] then
        player.insert {
            name = command.parameter,
            count = game.item_prototypes[command.parameter].stack_size
        }
    end
end)

commands.add_command("mark", "mark a position", function(command)
    local player = game.players[command.player_index]
    if not global.markers then global.markers = {} end
    if command.parameter then
        local args = string.split(command.parameter, " ")
        local pos = tools.fixCoords(args[1], args[2])
        table.insert(global.markers, tools.drawCircle(pos))
    else
        table.insert(global.markers, tools.drawCircle())
    end
end)

function tools.drawCircle(position, radius, color, width, filled, TTL)
    local circle = rendering.draw_circle {
        color = color or {r=0.5, g=1, b=1, a=0.5},
        radius = radius or 0.5,
        width = width or 1,
        filled = filled or true,
        target = position or player.position,
        players = {player.index},
        surface = player.surface,
        time_to_live = TTL or 60 * 5 * 60
    }
    return circle
end

-- commands.add_command("drawline",
--                      "draw a line\nusage: (use the semicolons to separate args)\n/drawline <position or entity 1>; <position or entity 2>; <table of players who can see>; <color>; <width>; <gap length>; <dash length>; <TTL>;",
--                      function(command)
--     local player = game.players[command.player_index]
--     local args = string.split(command.parameter, "; ")
--     local from = args[1] or player.character
--     local to = args[2] or player.selected
--     local players = args[3] or {player.index}
--     local color = args[4]
--     local width = args[5]
--     local gap_length = args[6]
--     local dash_length = args[7]
--     local time_to_live = args[8] * 60
--     local line = rendering.draw_line {
--         surface = player.surface,
--         from = args[1] or player.character,
--         to = args[2] or player.selected,
--         players = args[3] or {player},
--         color = args[4],
--         width = args[5],
--         gap_length = args[6],
--         dash_length = args[7],
--         time_to_live = args[8] * 60
--     }
-- end)

return tools
