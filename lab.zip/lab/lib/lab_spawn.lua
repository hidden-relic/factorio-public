local t = {
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "iron-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = -10.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "iron-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = -9.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "iron-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = -9.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "iron-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = -67,
      y = -6
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "copper-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = -2.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "copper-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = -1.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "copper-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = -1.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "copper-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "electric-energy-interface",
    position = {
      x = -67,
      y = 3
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "steel-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = 5.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "steel-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = 6.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "steel-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = 6.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 100,
        index = 1,
        mode = "at-least",
        name = "steel-plate"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = -67,
      y = 12
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 50,
        index = 1,
        mode = "at-least",
        name = "stone"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = 13.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 50,
        index = 1,
        mode = "at-least",
        name = "stone"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = 14.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 50,
        index = 1,
        mode = "at-least",
        name = "coal"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = 14.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_container_filters = {
      {
        count = 50,
        index = 1,
        mode = "at-least",
        name = "coal"
      }
    },
    name = "infinity-chest",
    position = {
      x = -67.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-loader",
    position = {
      x = -66,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "storage-tank",
    position = {
      x = -65.5,
      y = 22.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "storage-tank",
    position = {
      x = -65.5,
      y = 25.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_pipe_filters = {
      mode = "at-least",
      name = "crude-oil",
      percentage = 100,
      temperature = 25
    },
    name = "infinity-pipe",
    position = {
      x = -64.5,
      y = 21.5
    }
  },
  {
    direction = 0,
    force = "player",
    infinity_pipe_filters = {
      mode = "at-least",
      name = "water",
      percentage = 100,
      temperature = 15
    },
    name = "infinity-pipe",
    position = {
      x = -64.5,
      y = 26.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -57,
      y = -5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = -49,
      y = -6
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -63.5,
      y = 21.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -63.5,
      y = 26.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -57,
      y = 11
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -58.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -59.5,
      y = 26.5
    }
  },
  
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -53.5,
      y = 21.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -52.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -51.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -50.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -51.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -50.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -51.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -51.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -50.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -50.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -51.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -50.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -51.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -50.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -51.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -51.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -50.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -50.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -51.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -50.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -49.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -48.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -48,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -49.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -48.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -49.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -49.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -48.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -48.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -49.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -48.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = -49,
      y = 12
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -49.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -48.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -49.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -49.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -48.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -48.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -49.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -48.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -48.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -47.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -46.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -47.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -46.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -47.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -47.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -46.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -46.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -47.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -46.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -46.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -47.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -47.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -47.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -46.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -46.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -47.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -46.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -47.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -45.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -44.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -45.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -44.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -45.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -45.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -44.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -44.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -45.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -44.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -45.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -44.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -45.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -44.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -44.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -45.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -45.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -44.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -43.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -42.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -43.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -42.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -43.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -43.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -42.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -42.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -43.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -42.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -43.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -42.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -43.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -43.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -42.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -42.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -42.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -43.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -42.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -41.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -40.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -40,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -41.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -40.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -41.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -41.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -40.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -40.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -41.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -40.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -41.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -40.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -40.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -40.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -41.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -41.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -41.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -40.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -41.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -39.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -38.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -39.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -38.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -39.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -38.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -38.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -39.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -38.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -39.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -39.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -38.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -39.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -38.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -39.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -38.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -38.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -39.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -37.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -36.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -36.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -37.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -36.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -37.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -36.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -37.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -37.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -36.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -36.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -37.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -37.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -36.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -36.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -37.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -37.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -36.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -36.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -37.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -35.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -34.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -35.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -34.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -35.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -34.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -34.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -35.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -35.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -34.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -35.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -34.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -35.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -34.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -35.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -34.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -34.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -35.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -33.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -32.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -32,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -33.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -32.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -33.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -32.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -32.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -33.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -32.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -33.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -33.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -32.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -32.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -32.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -33.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -33.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -33.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -32.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = -31,
      y = -6
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -22,
      y = -5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = -13,
      y = -6
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = -9.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -3,
      y = -5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = -31,
      y = 12
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -30.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -31.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -31.5,
      y = 21.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -30.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -29.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -28.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -27.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -26.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -26.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -25.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -24.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -25.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -22,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -22,
      y = 11
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -23.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -22.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -21.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -20.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -20.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -19.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -18.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -19.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -17.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -16.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -14.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -15.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -15.5,
      y = 26.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -14.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -12,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = -13,
      y = 12
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -13.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -12.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -10.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -11.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -8.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -9.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -9.5,
      y = 21.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -8.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -6.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -7.5,
      y = 16.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -3,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = -3,
      y = 11
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -5.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -4.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -4.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -2.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -3.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = -3.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -1.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = -0.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 5,
      y = -6
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 23,
      y = -6
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 32,
      y = -5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 1.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 0.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 1.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 3.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 2.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 2.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 6,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 5,
      y = 12
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 4.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 5.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 7.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 6.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 7.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 6.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 8.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 9.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 11.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 10.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 14,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 13.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 12.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 13.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 12.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 15.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 14.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 17.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 16.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 17.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 19.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 18.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 18.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 22,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 21.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 20.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 23,
      y = 12
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 23.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 22.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 23.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 25.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 24.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 24.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 27.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 26.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 29.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 28.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 28.5,
      y = 26.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 29.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 32,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = 6.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 32,
      y = 11
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 31.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 30.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 41,
      y = -6
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 51,
      y = -5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = -8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 59,
      y = -6
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 33.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 32.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 35.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 34.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 34.5,
      y = 21.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 35.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 37.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 36.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 39.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 38.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 39.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 42,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 41,
      y = 12
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 41.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 40.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 40.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 43.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 42.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 45.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 44.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 45.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 47.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 46.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 46.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 51,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 51,
      y = 11
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 49.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 48.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 51.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 50.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 51.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 50.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 53.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 52.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 55.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 54.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 57.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 56.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 56.5,
      y = 21.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 57.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 60,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 59,
      y = 12
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 59.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 58.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 61.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 60.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 61.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 63.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 62.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 62.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 77,
      y = -6
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 86,
      y = -5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 95,
      y = -6
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 65.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 64.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 68,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 67.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 66.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 67.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 69.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 68.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 68.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 71.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 70.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 73.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 72.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 72.5,
      y = 26.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 73.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 76,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 75.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 74.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 77,
      y = 12
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 77.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 76.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 79.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 78.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 78.5,
      y = 21.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 79.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 81.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 80.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 83.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 82.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 83.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 86,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 86,
      y = 11
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 85.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 84.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 84.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 87.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 86.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 89.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 88.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 89.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 91.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 90.5,
      y = 16.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 90.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 93.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 92.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = 0.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "roboport",
    position = {
      x = 96,
      y = 3
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = 8.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "substation",
    position = {
      x = 95,
      y = 12
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 94.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 95.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 94.5,
      y = 26.5
    }
  },
  {
    direction = 6,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 95.5,
      y = 26.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = -8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = -7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = -1.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = -1.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 100.5,
      y = -16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = -10.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = -9.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = -8.5
    }
  },
  {
    direction = 4,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 100.5,
      y = -6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = -7.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 100.5,
      y = -5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = -2.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = -0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = -1.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 103.5,
      y = -16.5
    }
  },
  {
    direction = 4,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 103.5,
      y = -6.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 103.5,
      y = -5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 96.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 97.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = 0.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = 8.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = 13.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 99.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 98.5,
      y = 16.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 99.5,
      y = 21.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = 0.5
    }
  },
  {
    direction = 4,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 100.5,
      y = 2.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 100.5,
      y = 3.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = 5.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = 6.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = 7.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = 8.5
    }
  },
  {
    direction = 4,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 100.5,
      y = 11.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = 13.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 100.5,
      y = 12.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = 14.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = 15.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "express-transport-belt",
    position = {
      x = 100.5,
      y = 16.5
    }
  },
  {
    direction = 4,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 100.5,
      y = 20.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "storage-tank",
    position = {
      x = 101.5,
      y = 22.5
    }
  },
  {
    direction = 4,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 103.5,
      y = 2.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 103.5,
      y = 3.5
    }
  },
  {
    direction = 4,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 103.5,
      y = 11.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 103.5,
      y = 12.5
    }
  },
  {
    direction = 4,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 103.5,
      y = 22.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "storage-tank",
    position = {
      x = 104.5,
      y = 24.5
    }
  },
  {
    direction = 2,
    force = "player",
    name = "pipe-to-ground",
    position = {
      x = 104.5,
      y = 26.5
    }
  },
  {
    direction = 0,
    force = "player",
    name = "pipe",
    position = {
      x = 105.5,
      y = 26.5
    }
  }
}
return t