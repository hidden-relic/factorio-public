local util = require("util")

local str = ""

local function getIndent(n)
    local n = n or 1
    local indentation = " >"
    local str = ""
    for i = 1, n, 1 do str = str .. indentation end
    return str
end
local function blue(str) return "[color=blue]" .. tostring(str) .. "[/color]" end
local function green(str) return "[color=green]" .. tostring(str) .. "[/color]" end

function get_raw_resources()
    local raw_resources = {}
    local entities = game.entity_prototypes
    for name, entity_prototype in pairs(entities) do
        if entity_prototype.resource_category then
            if entity_prototype.mineable_properties then
                for k, product in pairs(entity_prototype.mineable_properties
                                            .products) do
                    raw_resources[product.name] = true
                end
            end
        end
        if entity_prototype.fluid then
            raw_resources[entity_prototype.fluid.name] = true
        end
    end
    return raw_resources
end

function get_product_list()
    local product_list = {}
    local recipes = game.recipe_prototypes

    for recipe_name, recipe_prototype in pairs(recipes) do
        if recipe_prototype.allow_decomposition then
            local ingredients = recipe_prototype.ingredients
            local products = recipe_prototype.products
            for k, product in pairs(products) do
                if not product_list[product.name] then
                    product_list[product.name] = {}
                end
                local recipe_ingredients = {}
                local product_amount = util.product_amount(product)
                if product_amount > 0 then
                    for j, ingredient in pairs(ingredients) do
                        recipe_ingredients[ingredient.name] =
                            ((ingredient.amount) / #products) / product_amount
                    end
                    recipe_ingredients.energy =
                        (recipe_prototype.energy / #products) / product_amount
                    table.insert(product_list[product.name], recipe_ingredients)
                end
            end
        end
    end

    local items = game.item_prototypes
    local entities = game.entity_prototypes
    --[[Now we do some tricky stuff for space science type items]]
    local rocket_silos = {}
    for k, entity in pairs(entities) do
        if entity.type == "rocket-silo" and entity.fixed_recipe then
            local recipe = recipes[entity.fixed_recipe]
            if not recipe then return end
            local required_parts = entity.rocket_parts_required
            local list = {}
            for k, product in pairs(recipe.products) do
                local product_amount = util.product_amount(product)
                if product_amount > 0 then
                    product_amount = product_amount * required_parts
                    list[product.name] = product_amount
                end
            end
            list["energy"] = recipe.energy
            table.insert(rocket_silos, list)
        end
    end
    for k, item in pairs(items) do
        local launch_products = item.rocket_launch_products
        if launch_products then
            for k, launch_product in pairs(launch_products) do
                product_list[launch_product.name] =
                    product_list[launch_product.name] or {}
                local launch_product_amount =
                    util.product_amount(launch_product)
                if launch_product_amount > 0 then
                    for k, silo_products in pairs(rocket_silos) do
                        local this_silo = {}
                        for product_name, product_count in pairs(silo_products) do
                            this_silo[product_name] = product_count /
                                                          launch_product_amount
                        end
                        this_silo[item.name] = 1 / launch_product.amount
                        table.insert(product_list[launch_product.name],
                                     this_silo)
                    end
                end
            end
        end
    end
    return product_list
end

function buildTree(recipe, count, indent)
    local p = game.player.print
    local str = str
    local recipe = recipe
    local products = recipe.products
    local count = count or 1
    count = count * products[1].amount
    local indent = indent or 1
    local recipes = game.recipe_prototypes
    local ingredients = recipe.ingredients
    local fluid_table = {
        ["petroleum-gas"] = true,
        ["light-oil"] = true,
        ["heavy-oil"] = true
    }
    if recipe then
        str = str .. getIndent(indent) ..
                  " x" .. count .. "\t" .. recipe.name .. "\n"
        if ingredients then
            indent = indent + 1
            for i, ingredient in pairs(ingredients) do
                if ingredient.type == "item" and recipes[ingredient.name] then
                    str = str ..
                              buildTree(recipes[ingredient.name],
                                        ingredient.amount, indent)
                elseif fluid_table[ingredient.name] then
                    str = str ..
                              buildTree(recipes["advanced-oil-processing"],
                                        ingredient.amount, indent)
                end
            end
        end
    else
        indent = indent - 1
    end
    return str
end

commands.add_command("buildtree",
                     "builds recipe tree\n/buildtree electronic-circuit",
                     function(command)
    local player = game.players[command.player_index]
    if command.parameter then
        if game.recipe_prototypes[command.parameter] then
            player.print(buildTree(game.recipe_prototypes[command.parameter]))
        elseif type(command.parameter) == "LuaRecipePrototype" then
            player.print(buildTree(command.parameter))
        end
    else
        game.write_file("recipe_test.txt", "")
        for _, item in pairs(game.recipe_prototypes) do
            game.write_file("recipe_test.txt", buildTree(item), true)
        end
    end
end)

commands.add_command("writedata", "writes some data to file", function(command)
    game.write_file("data/raw.lua", serpent.block(get_raw_resources()))
    game.write_file("data/product_list.lua", serpent.block(get_product_list()))
end)
