local t = {
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 2
          }
        }
      }
    },
    control_behavior = {
      filters = {
        {
          count = 1,
          index = 1,
          signal = {
            name = "signal-O",
            type = "virtual"
          }
        },
        {
          count = 1,
          index = 2,
          signal = {
            name = "signal-N",
            type = "virtual"
          }
        }
      },
      is_on = false
    },
    direction = 4,
    entity_number = 1,
    name = "constant-combinator",
    position = {
      x = -64.5,
      y = -13.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 1
          },
          {
            entity_id = 4
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 2,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = -10.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 4
          },
          {
            entity_id = 5
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 3,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = -8.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 2
          },
          {
            entity_id = 3
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 4,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = -9.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 3
          },
          {
            entity_id = 6
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 5,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = -7.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 5
          },
          {
            entity_id = 8
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 6,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = -2.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 8
          },
          {
            entity_id = 9
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 7,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = -0.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 6
          },
          {
            entity_id = 7
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 8,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = -1.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 7
          },
          {
            entity_id = 10
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 9,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = 0.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 9
          },
          {
            entity_id = 12
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 10,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = 5.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 12
          },
          {
            entity_id = 13
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 11,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = 7.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 10
          },
          {
            entity_id = 11
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 12,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = 6.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 11
          },
          {
            entity_id = 14
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 13,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = 8.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 13
          },
          {
            entity_id = 16
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 14,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = 13.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 16
          },
          {
            entity_id = 17
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 15,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = 15.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 14
          },
          {
            entity_id = 15
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 16,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = 14.5
    }
  },
  {
    connections = {
      ["1"] = {
        red = {
          {
            entity_id = 15
          }
        }
      }
    },
    control_behavior = {
      circuit_condition = {
        comparator = ">",
        constant = 0,
        first_signal = {
          name = "signal-O",
          type = "virtual"
        }
      },
      circuit_contents_read_mode = 0,
      circuit_enable_disable = true,
      circuit_read_hand_contents = false
    },
    direction = 2,
    entity_number = 17,
    name = "express-transport-belt",
    position = {
      x = -64.5,
      y = 16.5
    }
  }
}

return t