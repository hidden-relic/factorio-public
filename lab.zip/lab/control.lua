tools = require('lib/tools')
production_score = require('lib/production-score')
spawn_things = {
    lab_spawn_chests = require('lib/lab_spawn'),
    lab_spawn_wired_belts = require('lib/comb')
}
require('lib/commands')

require('lib/values')
require('lib/table')
require('lib/buildTree')
s = {}

script.on_init(function(event) s = tools.createLabSurface() end)

script.on_event(defines.events.on_tick, function(event)
    if game.tick == (5 * 60) then
        local t = {}
        for _, thing in pairs(spawn_things.lab_spawn_wired_belts) do
            thing.force = "neutral"
            table.insert(t, thing)
        end
        for _, thing in pairs(spawn_things.lab_spawn_chests) do
            if thing.name ~= "storage-tank" and thing.name ~=
                "express-transport-belt" then
                thing.force = "neutral"
                table.insert(t, thing)
            end
        end

        local last_thing = {}
        for i, thing in pairs(t) do
            local real_thing = s.create_entity(thing)
            if i <= #spawn_things.lab_spawn_wired_belts then
                if i > 1 and last_thing.valid then
                    local connected = real_thing.connect_neighbour({
                        wire = defines.wire_type.red,
                        target_entity = last_thing
                    })
                end
                last_thing = real_thing
            end
            if real_thing.name == "express-loader" then
                real_thing.direction = 6
                real_thing.loader_type = "output"
                local i, y = real_thing.position.x + 2, real_thing.position.y
                for x = i, i + 170, 1 do
                    local real_belt = s.create_entity {
                        name = "express-transport-belt",
                        position = {x = x, y = y},
                        direction = 2,
                        force = "neutral"
                    }
                end
            end
            if thing.infinity_pipe_filters then
                real_thing.set_infinity_pipe_filter(thing.infinity_pipe_filters)
            end
            if thing.infinity_container_filters then
                real_thing.infinity_container_filters =
                    thing.infinity_container_filters
            end
        end
        game.write_file("lab_spawn.lua", serpent.block(spawn_things))
    end
    if global.circles then
        for _, circle in pairs(global.circles) do
            if not circle.valid then circle = nil end
        end
    end
end)

script.on_event(defines.events.on_player_created, function(event)
    local player = game.players[event.player_index]
    tools.safeTeleport(player, s, {x = 0, y = 0})
    tools.givePowerArmorMK2(player)
    tools.giveTestKit(player)
    tools.givePlayerLongReach(player)
    p = player
    f = p.force
end)
