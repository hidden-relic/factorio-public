
--- WIP ---
--- Methods for manipulating a 'position'
-- @module position
-- @usage local position = require('utils.position')
--        local my_pos = game.player.position
--        local pos_to_modify = position:new(my_pos)    #### If no position is given as an argument, it defaults to 0, 0
--        pos_to_modify:move(4, 8)                      #### direction values are 0 for north, 2 for east, 4 for south, 6 for west. 1, 3, 5, 7 are valid

--        #### this would initialize a position, show the selection square, then move the selection square 8 spaces south

local color = require('utils.Colors')
position = {x = 0, y = 0}

function position:new(pos, surface)
    pos.marker = rendering.draw_rectangle {
        color = color.dark_orchid,
        filled = true,
        left_top = self,
        right_bottom = {x=self.x+1, y=self.y+1},
        surface = surface or game.surfaces[1],
        draw_on_ground = false,
        only_in_alt_mode = false
    }
    setmetatable(pos, self)
    self.__index = self
    return pos
end


function position:set(pos)
    if pos then
        self.x = pos.x
        self.y = pos.y
        if self.marker then
            rendering.set_left_top(self.marker, self)
            rendering.set_right_bottom(self.marker, {x=self.x+1, y=self.y+1})
        end
    end
end

function position:move(direction, amount)
    if type(direction) == "number" then
        if direction == 0 then self.y = self.y - amount end
        if direction == 1 then
            self.x = self.x + amount
            self.y = self.y - amount
        end
        if direction == 2 then self.x = self.x + amount end
        if direction == 3 then
            self.x = self.x + amount
            self.y = self.y + amount
        end
        if direction == 4 then self.y = self.y + amount end
        if direction == 5 then
            self.x = self.x - amount
            self.y = self.y + amount
        end
        if direction == 6 then self.x = self.x - amount end
        if direction == 7 then
            self.x = self.x - amount
            self.y = self.y - amount
        end
        if self.marker then
            rendering.set_left_top(self.marker, self)
            rendering.set_right_bottom(self.marker, {x=self.x+1, y=self.y+1})
        end
    end
end
