local tools = {}

function tools.index_table(table)
    local new_table = {}
    local str = ""

    for index, value in pairs(table) do
        if type(value) == "table" then
            tools.index_table(value)
        else
            new_table[#new_table + 1] = value
        end
    end
    return new_table
end






--[[ ------------------------  broken, WIP
     ------------------------  meant to be used with the area/position modules

function tools.fade_renderings()
    if (renders_fadeout and (#renders_fadeout > 0)) then
        for i, rend in pairs(renders_fadeout) do
            if (rendering.is_valid(rend)) then
                local ttl = rendering.get_time_to_live(rend)
                if ((ttl > 0) and (ttl < 200)) then
                    local color = rendering.get_color(rend)
                    if (color.a > 0) then
                        rendering.set_color(rend, {
                            r = color.r,
                            g = color.g,
                            b = color.b,
                            a = color.a - 0.005
                        })
                    end
                end
            else
                rendering.destroy(rend)
                renders_fadeout[i] = nil
            end
        end
    end
end

--]]


return tools