local color = require('utils.Colors')
local position = require('utils.position')

--- WIP ---
--- Methods for manipulating an 'area'
-- @module area
-- @usage local area = require('utils.area')
--        local my_area = area:new(bounding_box)    #### bounding-box is like {{x=3, y=6}, {x=6, y=9}} for shorthand, OR the correct way: {left_top={x=3, y=6}, right_bottom={x=6, y=9}}
--        #### if you don't supply an argument, use:
--        local my_area = area:from_position(position1, position2) #### position 2 is optional, if omitted it will make the area just 1 tile

--        my_area:grow(n) #### makes the area expand n tiles in all directions
--        my_area:shrink(n) #### makes the area shrink n tiles from all directions

--        my_area:add(direction, n) #### makes the area expand n tiles in given direction
--        my_area:subtract(direction, n) #### shrinks the area by n tiles from given direction (opposite of add)

--        my_area:shift(direction, n) #### moves the area n tiles in given direction

--        #### direction values are 0 for north, 2 for east, 4 for south, 6 for west. 1, 3, 5, 7 are valid

--        my_area:fill_tile(tile) #### fills the area with given tile
--        my_area:get_center() #### returns the center position in area
--        my_area:fill_inner_circle(tile) #### will create a filled circle within the bounds of the area with given tile

local area = {}

function area:new(box)
    box = box or {}
    if box.left_top.x > box.right_bottom.x then
        box.left_top.temp = box.left_top.x
        box.left_top.x = box.right_bottom.x
        box.right_bottom.x = box.left_top.temp
        box.left_top.temp = nil
    end
    if box.left_top.y > box.right_bottom.y then
        box.left_top.temp = box.left_top.y
        box.left_top.y = box.right_bottom.y
        box.right_bottom.y = box.left_top.temp
        box.left_top.temp = nil
    end
    -- box = fix_area(box)
    box.width = box.right_bottom.x-box.left_top.x
    box.height = box.right_bottom.y-box.left_top.y
    box.marker = rendering.draw_rectangle{
        color=color.hot_pink,
        width=1,
        filled = false,
        left_top = box.left_top,
        right_bottom = box.right_bottom,
        surface = game.surfaces[1],
        draw_on_ground = false,
        only_in_alt_mode = false
    }
    setmetatable(box, self)
    self.__index = self
    return box
end

function area:from_position(pos1, pos2)
    pos1.x = pos1.x or pos1[1]
    pos1.y = pos1.y or pos1[2]
    pos2 = pos2 or {}
    pos2.x = pos2.x or pos2[1] or pos1.x
    pos2.y = pos2.y or pos2[2] or pos1.y
    local box = {left_top={x=pos1.x, y=pos1.y}, right_bottom={x=pos2.x, y=pos2.y}}
    local new_area = area:new(box)
    return new_area
end

function area:grow(amount)
    self:move_left_top(7, amount)
    self:move_right_bottom(3, amount)
end

function area:shrink(amount)
    self:move_left_top(3, amount)
    self:move_right_bottom(7, amount)
end

function area:add(direction, amount)
    if direction == 0 or direction == 6 then self:move_left_top(direction, amount) end
    if direction == 2 or direction == 4 then self:move_right_bottom(direction, amount) end
end

function area:subtract(direction, amount)
    if direction == 2 or direction == 4 then self:move_left_top(direction, amount) end
    if direction == 0 or direction == 6 then self:move_right_bottom(direction, amount) end
end

function area:shift(direction, amount)
    self:move_left_top(direction, amount)
    self:move_right_bottom(direction, amount)
end

function area:move_left_top(direction, amount)
    amount = amount or 1
    if type(direction) == "number" then
        if direction == 0 then self.left_top.y = self.left_top.y-amount end
        if direction == 1 then self.left_top.x = self.left_top.x+amount self.left_top.y = self.left_top.y-amount end
        if direction == 2 then self.left_top.x = self.left_top.x+amount end
        if direction == 3 then self.left_top.x = self.left_top.x+amount self.left_top.y = self.left_top.y+amount end
        if direction == 4 then self.left_top.y = self.left_top.y+amount end
        if direction == 5 then self.left_top.x = self.left_top.x-amount self.left_top.y = self.left_top.y+amount end
        if direction == 6 then self.left_top.x = self.left_top.x-amount end
        if direction == 7 then self.left_top.x = self.left_top.x-amount self.left_top.y = self.left_top.y-amount end
        end
    rendering.set_left_top(self.marker, self.left_top)
    rendering.set_right_bottom(self.marker, self.right_bottom)
    self.width = self.right_bottom.x-self.left_top.x
    self.height = self.right_bottom.y-self.left_top.y
end

function area:move_right_bottom(direction, amount)
    amount = amount or 1
    if type(direction) == "number" then
        if direction == 0 then self.right_bottom.y = self.right_bottom.y-amount end
        if direction == 1 then self.right_bottom.x = self.right_bottom.x+amount self.right_bottom.y = self.right_bottom.y-amount end
        if direction == 2 then self.right_bottom.x = self.right_bottom.x+amount end
        if direction == 3 then self.right_bottom.x = self.right_bottom.x+amount self.right_bottom.y = self.right_bottom.y+amount end
        if direction == 4 then self.right_bottom.y = self.right_bottom.y+amount end
        if direction == 5 then self.right_bottom.x = self.right_bottom.x-amount self.right_bottom.y = self.right_bottom.y+amount end
        if direction == 6 then self.right_bottom.x = self.right_bottom.x-amount end
        if direction == 7 then self.right_bottom.x = self.right_bottom.x-amount self.right_bottom.y = self.right_bottom.y-amount end
        end
    rendering.set_left_top(self.marker, self.left_top)
    rendering.set_right_bottom(self.marker, self.right_bottom)
    self.width = self.right_bottom.x-self.left_top.x
    self.height = self.right_bottom.y-self.left_top.y
end

function area:fill_tile(tile)
    local tiles = {}
    for i = self.left_top.x, self.right_bottom.x-1, 1 do
        for j = self.left_top.y, self.right_bottom.y-1, 1 do
            local tile_data = {name = tile, position = {x = i, y = j}}
            table.insert(tiles, tile_data)
        end
    end
    return tiles
end

 

function area:get_center()
    local center = {}
    center.x = (self.left_top.x + self.right_bottom.x) / 2
    center.y = (self.left_top.y + self.right_bottom.y) / 2
    if self.width % 2 == 0 then
        center.x = center.x-0.5
    end
    if self.height % 2 == 0 then
        center.y = center.y-0.5
    end
    return center
end

function area:fill_inner_circle(tile)
    local tiles = {}
    local r = 0
    if self.width >= self.height then
        r = self.height/2
    else r = self.width/2
    end
    local r_sq = r ^ 2
    local center = self:get_center()
    for i = self.left_top.x, self.right_bottom.x, 1 do
        for j = self.left_top.y, self.right_bottom.y, 1 do
            local dist = math.floor((center.x - i) ^ 2 + (center.y - j) ^ 2)
            if (dist < r_sq) then
                local tile_data = {name = tile, position = {x = i, y = j}}
                table.insert(tiles, tile_data)
            end
            
            -- local wall_space = r*math.pi
            -- if ((dist < r_sq) and
            -- (dist > r_sq-wall_space)) then
            --    game.player.surface.create_entity({name="stone-wall", amount=1, position={i, j}})
            -- end
        end
    end
    return tiles
end