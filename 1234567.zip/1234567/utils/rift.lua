local world_spawn = require('utils.world_spawn')
local command_list = require('utils.commands')
local gui = require('flib.gui')
local styles = require('flib.styles')
local mod_gui = require("__core__.lualib.mod-gui")
local table = require("flib.table")

rift = {
    belts = {input = {}, output = {}},
    wagon = {},
    combinator = {},
    global_pool = {items = {}, requests = {}},
    turrets = {}
}

rift.config = {
    test_map = false,
    custom_spawn = {
        toggled = true,
        clear_area = true,
        use_landfill = true,
        use_entities = true,
        use_turrets = true,
        use_tiles = true,
        use_storage_wagon = true
    },
    use_custom_map_settings = false,
    map_gen_settings = {
        autoplace_controls = {
            coal = {frequency = 1, richness = 2, size = 1},
            ["copper-ore"] = {frequency = 1, richness = 2, size = 1},
            ["crude-oil"] = {frequency = 1, richness = 2, size = 1},
            ["enemy-base"] = {frequency = 1, richness = 1, size = 1},
            ["iron-ore"] = {frequency = 1, richness = 2, size = 1},
            stone = {frequency = 1, richness = 2, size = 1},
            trees = {frequency = 1, richness = 1, size = 1},
            ["uranium-ore"] = {frequency = 1, richness = 2, size = 1}
        },
        autoplace_settings = {},
        cliff_settings = {
            cliff_elevation_0 = 10,
            cliff_elevation_interval = 40,
            name = "cliff",
            richness = 0
        },
        height = 2000000,
        peaceful_mode = false,
        property_expression_names = {},
        seed = 1782685488,
        starting_area = 6,
        starting_points = {{x = 0, y = 0}},
        terrain_segmentation = 1,
        water = 1,
        width = 2000000
    },
    map_settings = {
        difficulty_settings = {
            recipe_difficulty = 0,
            research_queue_setting = "after-victory",
            technology_difficulty = 0,
            technology_price_multiplier = 1
        },
        enemy_evolution = {
            destroy_factor = 0.002,
            enabled = true,
            pollution_factor = 9e-07,
            time_factor = 4e-06
        },
        enemy_expansion = {
            building_coefficient = 0.1,
            enabled = false,
            enemy_building_influence_radius = 2,
            friendly_base_influence_radius = 2,
            max_colliding_tiles_coefficient = 0.9,
            max_expansion_cooldown = 216000,
            max_expansion_distance = 7,
            min_expansion_cooldown = 14400,
            neighbouring_base_chunk_coefficient = 0.4,
            neighbouring_chunk_coefficient = 0.5,
            other_base_coefficient = 2,
            settler_group_max_size = 20,
            settler_group_min_size = 5
        },
        max_failed_behavior_count = 3,
        path_finder = {
            cache_accept_path_end_distance_ratio = 0.15,
            cache_accept_path_start_distance_ratio = 0.2,
            cache_max_connect_to_cache_steps_multiplier = 100,
            cache_path_end_distance_rating_multiplier = 20,
            cache_path_start_distance_rating_multiplier = 10,
            direct_distance_to_consider_short_request = 100,
            enemy_with_different_destination_collision_penalty = 30,
            extended_collision_penalty = 3,
            fwd2bwd_ratio = 5,
            general_entity_collision_penalty = 10,
            general_entity_subsequent_collision_penalty = 3,
            goal_pressure_ratio = 2,
            ignore_moving_enemy_collision_distance = 5,
            long_cache_min_cacheable_distance = 30,
            long_cache_size = 25,
            max_clients_to_accept_any_new_request = 10,
            max_clients_to_accept_short_new_request = 100,
            max_steps_worked_per_tick = 1000,
            max_work_done_per_tick = 8000,
            min_steps_to_check_path_find_termination = 2000,
            negative_cache_accept_path_end_distance_ratio = 0.3,
            negative_cache_accept_path_start_distance_ratio = 0.3,
            negative_path_cache_delay_interval = 20,
            overload_levels = {0, 100, 500},
            overload_multipliers = {2, 3, 4},
            short_cache_min_algo_steps_to_cache = 50,
            short_cache_min_cacheable_distance = 10,
            short_cache_size = 5,
            short_request_max_steps = 1000,
            short_request_ratio = 0.5,
            stale_enemy_with_same_destination_collision_penalty = 30,
            start_to_goal_cost_multiplier_to_terminate_path_find = 2000,
            use_path_cache = true
        },
        pollution = {
            ageing = 1,
            diffusion_ratio = 0.02,
            enabled = true,
            enemy_attack_pollution_consumption_modifier = 1,
            expected_max_per_chunk = 0,
            max_pollution_to_restore_trees = 20,
            min_pollution_to_damage_trees = 60,
            min_to_diffuse = 15,
            min_to_show_per_chunk = 0,
            pollution_per_tree_damage = 50,
            pollution_restored_per_tree_damage = 10,
            pollution_with_max_forest_damage = 150
        },
        steering = {
            default = {
                force_unit_fuzzy_goto_behavior = false,
                radius = 1.2,
                separation_factor = 1.2,
                separation_force = 0.005
            },
            moving = {
                force_unit_fuzzy_goto_behavior = false,
                radius = 3,
                separation_factor = 3,
                separation_force = 0.01
            }
        },
        unit_group = {
            max_gathering_unit_groups = 30,
            max_group_gathering_time = 36000,
            max_group_member_fallback_factor = 3,
            max_group_radius = 30,
            max_group_slowdown_factor = 0.3,
            max_member_slowdown_when_ahead = 0.6,
            max_member_speedup_when_behind = 1.3999999999999999,
            max_unit_group_size = 200,
            max_wait_time_for_late_members = 7200,
            member_disown_distance = 10,
            min_group_gathering_time = 3600,
            min_group_radius = 5,
            tick_tolerance_when_member_arrives = 60
        }
    }
}

rift.global_pool_gui = {}

function rift.global_pool_gui.build(player, player_table)
    local refs = gui.build(player.gui.screen, {
        {
            type = "frame",
            direction = "vertical",
            ref = {"window"},
            actions = {on_closed = "close_global_pool_gui"},
            -- Titlebar
            {
                type = "flow",
                ref = {"titlebar_flow"},
                {
                    type = "label",
                    style = "frame_title",
                    caption = "Global Pool",
                    ignored_by_interaction = true
                },
                {
                    type = "empty-widget",
                    style_mods = styles["flib_titlebar_drag_handle"],
                    ignored_by_interaction = true
                },
                {
                    type = "sprite-button",
                    style = "frame_action_button",
                    sprite = "utility/close_white",
                    hovered_sprite = "utility/close_black",
                    clicked_sprite = "utility/close_black",
                    ref = {"titlebar", "close_button"},
                    actions = {on_click = "close_global_pool_gui"}
                }
            },
            -- Content
            {
                type = "flow",
                ref = {"content_flow"},
                {
                    type = "scroll-pane",
                    ref = {"item_list"},
                    direction = "vertical"
                }
            }
        }
    })

    refs.titlebar_flow.drag_target = refs.window
    refs.window.force_auto_center()

    player_table.global_pool_gui = {
        refs = refs,
        state = {items = {}, next_id = 1}
    }
end

function rift.global_pool_gui.update(e)
    local player_table = global.players[e.player_index]
    local gui_data = player_table.global_pool_gui
    local state = gui_data.state
    local refs = gui_data.refs
    state.items = {}

    for __, item in pairs(rift.global_pool.items) do
        if item.count > 0 then
            state.items[state.next_id] = {name = item.name, count = item.count}
            state.next_id = state.next_id + 1
        end
    end

    local item_list = refs.item_list
    local children = item_list.children
    local i = 0
    for id, item in pairs(state.items) do
        i = i + 1
        local child = children[i]
        if child then
            gui.update(child, {
                {
                    elem_mods = {caption = "[item=" .. item.name .. "]"},
                    tags = {item_id = id}
                }, {elem_mods = {caption = item.count}, tags = {item_id = id}},
                {elem_mods = {caption = item.name}, tags = {item_id = id}}
            })
        else
            gui.add(item_list, {
                type = "flow",
                style_mods = {vertical_align = "center"},
                {
                    type = "label",
                    caption = "[item=" .. item.name .. "]",
                    tags = {item_id = id}
                },
                {type = "label", caption = item.count, tags = {item_id = id}},
                {type = "label", caption = item.name, tags = {item_id = id}}
            })
        end
    end
    for j = i + 1, #children do children[j].destroy() end

    if i == 0 then
        item_list.visible = false
    else
        item_list.visible = true
    end
end

function rift.global_pool_gui.open(e)
    local player = game.get_player(e.player_index)
    local player_table = global.players[e.player_index]
    local gui_data = player_table.global_pool_gui

    gui_data.refs.window.visible = true
    player.opened = gui_data.refs.window
end

function rift.global_pool_gui.close(e)
    local player = game.get_player(e.player_index)
    local player_table = global.players[e.player_index]
    local gui_data = player_table.global_pool_gui

    gui_data.refs.window.visible = false
    if player.opened then player.opened = nil end
end

function rift.init()
    local surface = game.surfaces[1]
    local cfg = rift.config
    if cfg.test_map == true then
        surface.clear(true)
        surface.generate_with_lab_tiles = true
    end
    if cfg.use_custom_map_settings == true then
        surface.map_gen_settings = cfg.map_gen_settings
        for setting_name, setting in pairs(cfg.map_settings) do
            game.map_settings[setting_name] = setting
        end
    end


    if cfg.custom_spawn.toggled then
        if cfg.custom_spawn.clear_area then rift.clear_space(surface) end
        if cfg.custom_spawn.use_landfill then rift.set_landfill(surface) end
        if cfg.custom_spawn.use_entities then
            rift.spawn_entities(surface)
        end
        if cfg.custom_spawn.use_turrets then rift.spawn_turrets(surface) end
        if cfg.custom_spawn.use_tiles then rift.set_tiles(surface) end
        if cfg.custom_spawn.use_storage_wagon then
            local rift_index = #rift.wagon + 1
            rift.wagon[rift_index] = rift.spawn_wagon(surface)
            rift.combinator[rift_index] = rift.spawn_combinator(surface)
        end
    end
end

function rift.deposit(item_name, count)
    local count = count or 0
    if (not game.item_prototypes[item_name].has_flag("hidden")) then
        if (rift.global_pool.items[item_name] == nil) then
            rift.global_pool.items[item_name] = {
                name = item_name,
                count = count
            }
        else
            rift.global_pool.items[item_name].count =
                rift.global_pool.items[item_name].count + count
        end
        return true
    else
        return false
    end
end

function rift.empty_equipment(item_stack)
    if (item_stack == nil) then return end

    if (item_stack.grid == nil) then return end

    local contents = item_stack.grid.get_contents()
    for item_name, count in pairs(contents) do rift.deposit(item_name, count) end
end

function rift.deposit_wagon(wagon)

    local wagon_inv = wagon.get_inventory(defines.inventory.cargo_wagon)
    if (wagon_inv == nil) then return end
    if (wagon_inv.is_empty()) then return end

    local contents = wagon_inv.get_contents()
    for item_name, count in pairs(contents) do
        if (game.item_prototypes[item_name].equipment_grid ~= nil) then
            local item_stack = wagon_inv.find_item_stack(item_name)
            while (item_stack ~= nil) do
                rift.empty_equipment(item_stack)
                item_stack.clear()
                item_stack = wagon_inv.find_item_stack(item_name)
            end
        end

        if (rift.deposit(item_name, count)) then
            wagon_inv.remove({name = item_name, count = count})
        end
    end
end

function rift.deposit_all()

    if rift.global_pool.items == nil then rift.global_pool.items = {} end

    for index, wagon in pairs(rift.wagon) do

        -- Delete any wagon that is no longer valid.
        if ((wagon == nil) or (not wagon.valid)) then
            rift.wagon[index] = nil

            -- Take inputs and store.
        else
            rift.deposit_wagon(wagon)
        end
    end
end

function rift.tally_requests()
    rift.requests = {}
    for index, wagon in pairs(rift.wagon) do
        local combinator = rift.combinator[index]
        -- Check if combinator still exists
        if (combinator == nil) or (not combinator.valid) then
            rift.combinator[index] = nil
        else
            -- Get signals on the ctrl combinatori:
            local combinator_behavior =
                combinator.get_or_create_control_behavior()
            for i = 1, combinator_behavior.signals_count do
                local sig = combinator_behavior.get_signal(i)
                if ((sig ~= nil) and (sig.signal ~= nil) and
                    (sig.signal.type == "item")) then
                    if rift.requests[sig.signal.name] == nil then
                        rift.requests[sig.signal.name] = {
                            name = sig.signal.name,
                            count = 0
                        }
                    end
                    -- Calculate actual request to fill remainder
                    local existingAmount =
                        wagon.get_inventory(defines.inventory.cargo_wagon)
                            .get_item_count(sig.signal.name)
                    local requestAmount =
                        math.max(sig.count - existingAmount, 0)

                    -- Add the request counts
                    rift.requests[sig.signal.name].name = sig.signal.name
                    rift.requests[sig.signal.name].count =
                        rift.requests[sig.signal.name].count + requestAmount
                end
                -- If demand is more than supply, limit each player's total item request to shared amount
                for __, request in pairs(rift.requests) do
                    if not rift.global_pool.items[request.name] then
                        rift.global_pool.items[request.name] = {
                            name = request.name,
                            count = 0
                        }
                    end
                    local cap = 0
                    if (request == nil) or (request.count == 0) then
                        cap = 0

                        -- Otherwise, limit by dividing by players.
                    elseif (request.count >
                        rift.global_pool.items[request.name].count) then
                        cap = math.floor(
                                  rift.global_pool.items[request.name].count)
                    end

                    -- In the case where we are rounding down to 0, let's bump the minimum distribution to 1.
                    if (cap == 0) then cap = 1 end
                end
            end
        end
    end
end

function rift.distribute_requests()
    for index, wagon in pairs(rift.wagon) do
        -- Delete any wagon that is no longer valid.
        if ((wagon == nil) or (not wagon.valid)) then
            rift.wagon[index] = nil
            -- For each request slot
        else
            local combinator = rift.combinator[index]
            -- Check if combinator still exists
            if (combinator == nil) or (not combinator.valid) then
                rift.combinator[index] = nil
            else
                for each, request in pairs(rift.requests) do
                    if (request ~= nil) and (request.count > 0) and
                        (rift.global_pool.items[request.name] ~= nil) then

                        if (request.count > 0) and
                            (rift.global_pool.items[request.name].count > 0) then

                            -- How much is already in the chest?
                            local existingAmount =
                                wagon.get_inventory(defines.inventory
                                                        .cargo_wagon)
                                    .get_item_count(request.name)
                            -- How much is required to fill the remainder request?
                            local requestAmount =
                                math.max(request.count - existingAmount, 0)
                            -- How much is allowed based on the player's current request amount?
                            local allowedAmount =
                                math.min(requestAmount, request.count)

                            if (allowedAmount > 0) then
                                local wagonInv =
                                    wagon.get_inventory(defines.inventory
                                                            .cargo_wagon)
                                if wagon.can_insert({name = request.name}) then

                                    local amnt = wagon.insert {
                                        name = request.name,
                                        count = math.min(allowedAmount,
                                                         rift.global_pool.items[request.name]
                                                             .count)
                                    }

                                    rift.global_pool.items[request.name].count =
                                        rift.global_pool.items[request.name]
                                            .count - amnt

                                    rift.requests[request.name].count =
                                        rift.requests[request.name].count - amnt

                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

function rift.clear_space(surface, position)
    if surface.valid then
        local position = position or {x = 0, y = 0}
        local cleanup_entities = surface.find_entities_filtered {
            area = {
                left_top = {x = position.x - 50, y = position.y - 50},
                right_bottom = {x = position.x + 50, y = position.y + 50}
            }
        }

        for each, entity in pairs(cleanup_entities) do
            if entity.type ~= "resource" and entity.type ~= "character" then
                entity.destroy()
            end
        end
    end
end

function rift.set_landfill(surface) surface.set_tiles(world_spawn.landfill) end

function rift.spawn_entities(surface)
    for each, entity in pairs(world_spawn.entities) do
        surface.create_entity(entity)
    end
end

function rift.spawn_turrets(surface)
    for each, turret in pairs(world_spawn.turrets) do
        local t = surface.create_entity(turret)
        t.insert {name = "piercing-rounds-magazine", count = 25}
        table.insert(rift.turrets, t)
    end
end

function rift.reload_turrets(turrets)
    for each, turret in pairs(turrets) do
        if not turret then return end
        local turret_inv = turret.get_inventory(defines.inventory.turret_ammo)
        if turret_inv[1].count < 25 then
            turret.insert {
                name = "piercing-rounds-magazine",
                count = 25 - turret_inv[1].count
            }
        end
    end
end

function rift.set_tiles(surface) surface.set_tiles(world_spawn.tiles) end

function rift.spawn_wagon(surface)
    local new_rift = surface.create_entity {
        position = {x = 0, y = -33},
        name = "cargo-wagon",
        direction = 2,
        force = "player"
    }
    return new_rift
end

function rift.spawn_combinator(surface)
    local rift_combinator = surface.create_entity {
        position = {x = 6.5, y = -19.5},
        name = "constant-combinator",
        direction = 0,
        force = "player"
    }
    return rift_combinator
end

return rift
