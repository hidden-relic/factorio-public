local config = {
    power_armor = {toggled = true, admin_only = true},
    load_quickbar = {toggled = true, admin_only = false},

    -- start_items uses the items from command.quickbar (load_quickbar)
    start_items = {
        toggled = true,
        normal = {
            items = {
                {name = "iron-plate", count = 250},
                {name = "copper-plate", count = 250},
                {name = "steel-plate", count = 50},
                {name = "burner-mining-drill", count = 10},
                {name = "transport-belt", count = 100},
                {name = "splitter", count = 10},
                {name = "underground-belt", count = 10},
                {name = "inserter", count = 25}, {name = "coal", count = 200}
            }
        },
        cheaty = {
            toggled = false,
            admin_only = true
        },
    },

    robot_boost = {toggled = true, speed = 5, battery = 1, storage = 1},
    cheat_mode = {toggled = false, admin_only = true},
    research_queue = {toggled = true}
}

return config
