local color = require('utils.Colors')
local math = require('utils.Math')
local config = require('utils.config')

local command = {}

function command.format_chat_color(message, color)
    color = color or color.white
    local color_tag = '[color=' .. math.round(color.r, 3) .. ', ' ..
                          math.round(color.g, 3) .. ', ' ..
                          math.round(color.b, 3) .. ']'
    return string.format('%s%s[/color]', color_tag, message)
end

function command.step_component(c1, c2)
    if c1 < 0 then
        return 0, c2 + c1
    elseif c1 > 1 then
        return 1, c2 - c1 + 1
    else
        return c1, c2
    end
end

function command.step_color(color)
    color.r, color.g = command.step_component(color.r, color.g)
    color.g, color.b = command.step_component(color.g, color.b)
    color.b, color.r = command.step_component(color.b, color.r)
    color.r = command.step_component(color.r, 0)
    return color
end

function command.next_color(color, step)
    step = step or 0.1
    local new_color = {r = 0, g = 0, b = 0}
    if color.b == 0 and color.r ~= 0 then
        new_color.r = color.r - step
        new_color.g = color.g + step
    elseif color.r == 0 and color.g ~= 0 then
        new_color.g = color.g - step
        new_color.b = color.b + step
    elseif color.g == 0 and color.b ~= 0 then
        new_color.b = color.b - step
        new_color.r = color.r + step
    end
    return command.step_color(new_color)
end

--- Sends an rainbow message in the chat
-- @command rainbow
-- @tparam string message the message that will be printed in chat

commands.add_command('rainbow', 'Sends an rainbow message in the chat',
                     function(command)
    local player = game.players[command.player_index]
    local message = command.parameter
    local player_name = player and player.name or '<Server>'
    local player_color = player and player.color or nil
    local color_step = 3 / message:len()
    if color_step > 1 then color_step = 1 end
    local current_color = {r = 1, g = 0, b = 0}
    local output = command.format_chat_color(player_name .. ': ', player_color)
    output = output .. message:gsub('%S', function(letter)
        local rtn = command.format_chat_color(letter, current_color)
        current_color = command.next_color(current_color, color_step)
        return rtn
    end)
    game.print(output)
end)

-- #########################################################

commands.add_command('dump_layout', 'Dump the current map-layout.',
                     function(command)
    local player = game.players[command.player_index]

    if not (player and player.valid) then return end

    local range = 32
    local max_range = 3200
    if (command.parameter ~= nil) then range = tonumber(command.parameter) end
    if not range or max_range and range > max_range then
        player.print('Maximum Range is 3200.')
        return
    end

    local p = player.print
    if not player.admin then
        p("[ERROR] You're not admin!")
        return
    end
    local surface = game.players[1].surface
    game.write_file('layout.lua', '', false)

    local area = {
        left_top = {
            x = player.position.x - range,
            y = player.position.y - range
        },
        right_bottom = {
            x = player.position.x + range,
            y = player.position.y + range
        }
    }

    local entities = surface.find_entities_filtered {area = area}
    local tiles = surface.find_tiles_filtered {area = area}

    for _, e in pairs(entities) do
        local str = '{position = {x = ' .. e.position.x
        str = str .. ', y = '
        str = str .. e.position.y
        str = str .. '}, name = "'
        str = str .. e.name
        str = str .. '", direction = '
        str = str .. tostring(e.direction)
        str = str .. ', force = "'
        str = str .. e.force.name
        str = str .. '"},'
        if e.name ~= 'character' then
            game.write_file('layout.lua', str .. '\n', true)
        end
    end

    game.write_file('layout.lua', '\n', true)
    game.write_file('layout.lua', '\n', true)
    game.write_file('layout.lua', 'Tiles: \n', true)

    for _, t in pairs(tiles) do
        local str = '{position = {x = ' .. t.position.x
        str = str .. ', y = '
        str = str .. t.position.y
        str = str .. '}, name = "'
        str = str .. t.name
        str = str .. '"},'
        game.write_file('layout.lua', str .. '\n', true)
        player.print('Dumped layout as file: layout.lua')
    end
end)

-- ################################################

commands.add_command("repair",
                     "Repairs all destroyed and damaged entities in an area",
                     function(command)

    local player = game.players[command.player_index]
    if player ~= nil and player.admin then
        local range = 50
        local max_range = 1000
        if (command.parameter ~= nil) then
            range = tonumber(command.parameter)
        end
        if not range or max_range and range > max_range then
            player.print('Maximum Range is 1000.')
            return
        end

        local revive_count = 0
        local heal_count = 0
        local range2 = range ^ 2
        local surface = player.surface
        local center = player.position
        local area = {
            {x = center.x - range, y = center.y - range},
            {x = center.x + range, y = center.y + range}
        }

        local ghosts = surface.find_entities_filtered({
            area = area,
            type = 'entity-ghost',
            force = player.force
        })
        for _, ghost in pairs(ghosts) do
            if ghost.valid then
                local x = ghost.position.x - center.x
                local y = ghost.position.y - center.y
                if x ^ 2 + y ^ 2 <= range2 then
                    revive_count = revive_count + 1
                    ghost.silent_revive()
                end
            end
        end

        local entities = surface.find_entities_filtered({
            area = area,
            force = player.force
        })
        for _, entity in pairs(entities) do
            if entity.valid then
                local x = entity.position.x - center.x
                local y = entity.position.y - center.y
                if entity.health and entity.get_health_ratio() ~= 1 and x ^ 2 +
                    y ^ 2 <= range2 then
                    heal_count = heal_count + 1
                    entity.health = 100000
                end
            end
        end
        player.print(
            revive_count .. " ghosts were revived and " .. heal_count ..
                " entities were healed.")
    end
end)

-- ################################################

command.quick_bar = {
    "transport-belt", "splitter", "underground-belt", "inserter",
    "small-electric-pole", "assembling-machine-1", "electric-mining-drill",
    "stone-wall", "gun-turret", "radar", "fast-transport-belt", "fast-splitter",
    "fast-underground-belt", "fast-inserter", "medium-electric-pole",
    "assembling-machine-2", nil, nil, nil, nil, "express-transport-belt",
    "express-splitter", "express-underground-belt", "stack-inserter",
    "substation", "assembling-machine-3", "beacon", nil, nil, nil, "loader",
    "fast-loader", "express-loader"
}

function command.load_quickbar(player)
    player.set_quick_bar_slot(1, command.quick_bar[1]);
    player.set_quick_bar_slot(2, command.quick_bar[2]);
    player.set_quick_bar_slot(3, command.quick_bar[3]);
    player.set_quick_bar_slot(4, command.quick_bar[4]);
    player.set_quick_bar_slot(5, command.quick_bar[5]);

    player.set_quick_bar_slot(6, command.quick_bar[6]);
    player.set_quick_bar_slot(7, command.quick_bar[7]);
    player.set_quick_bar_slot(8, command.quick_bar[8]);
    player.set_quick_bar_slot(9, command.quick_bar[9]);
    player.set_quick_bar_slot(10, command.quick_bar[10]);

    player.set_quick_bar_slot(11, command.quick_bar[11]);
    player.set_quick_bar_slot(12, command.quick_bar[12]);
    player.set_quick_bar_slot(13, command.quick_bar[13]);
    player.set_quick_bar_slot(14, command.quick_bar[14]);
    player.set_quick_bar_slot(15, command.quick_bar[15]);

    player.set_quick_bar_slot(16, command.quick_bar[16]);
    player.set_quick_bar_slot(17, command.quick_bar[17]);
    player.set_quick_bar_slot(18, command.quick_bar[18]);
    player.set_quick_bar_slot(19, command.quick_bar[19]);
    player.set_quick_bar_slot(20, command.quick_bar[20]);

    player.set_quick_bar_slot(21, command.quick_bar[21]);
    player.set_quick_bar_slot(22, command.quick_bar[22]);
    player.set_quick_bar_slot(23, command.quick_bar[23]);
    player.set_quick_bar_slot(24, command.quick_bar[24]);
    player.set_quick_bar_slot(25, command.quick_bar[25]);

    player.set_quick_bar_slot(26, command.quick_bar[26]);
    player.set_quick_bar_slot(27, command.quick_bar[27]);
    player.set_quick_bar_slot(28, command.quick_bar[28]);
    player.set_quick_bar_slot(29, command.quick_bar[29]);
    player.set_quick_bar_slot(30, command.quick_bar[30]);

    player.set_quick_bar_slot(31, command.quick_bar[31]);
    player.set_quick_bar_slot(32, command.quick_bar[32]);
    player.set_quick_bar_slot(33, command.quick_bar[33]);
    --[[
    player.set_quick_bar_slot(34, "fast-underground-belt");
    player.set_quick_bar_slot(35, "fast-splitter");

    player.set_quick_bar_slot(36, "stone-wall");
    player.set_quick_bar_slot(37, "repair-pack");
    player.set_quick_bar_slot(38, "gun-turret");
    player.set_quick_bar_slot(39, "laser-turret");
    player.set_quick_bar_slot(40, "radar");

    -- 5th Row
    player.set_quick_bar_slot(41, "train-stop");
    player.set_quick_bar_slot(42, "rail-signal");
    player.set_quick_bar_slot(43, "rail-chain-signal");
    player.set_quick_bar_slot(44, "rail");
    player.set_quick_bar_slot(45, "big-electric-pole");

    player.set_quick_bar_slot(46, "locomotive");
    player.set_quick_bar_slot(47, "cargo-wagon");
    player.set_quick_bar_slot(48, "fluid-wagon");
    player.set_quick_bar_slot(49, "pump");
    player.set_quick_bar_slot(50, "storage-tank");

    -- 6th Row
    player.set_quick_bar_slot(51, "oil-refinery");
    player.set_quick_bar_slot(52, "chemical-plant");
    player.set_quick_bar_slot(53, "storage-tank");
    player.set_quick_bar_slot(54, "pump");
    player.set_quick_bar_slot(55, nil);

    player.set_quick_bar_slot(56, "pipe");
    player.set_quick_bar_slot(57, "pipe-to-ground");
    player.set_quick_bar_slot(58, "assembling-machine-2");
    player.set_quick_bar_slot(59, "pump");
    player.set_quick_bar_slot(60, nil);

    -- 7th Row
    player.set_quick_bar_slot(61, "roboport");
    player.set_quick_bar_slot(62, "logistic-chest-storage");
    player.set_quick_bar_slot(63, "logistic-chest-passive-provider");
    player.set_quick_bar_slot(64, "logistic-chest-requester");
    player.set_quick_bar_slot(65, "logistic-chest-buffer");

    player.set_quick_bar_slot(66, "logistic-chest-active-provider");
    player.set_quick_bar_slot(67, "logistic-robot");
    player.set_quick_bar_slot(68, "construction-robot");
    player.set_quick_bar_slot(69, nil);
    player.set_quick_bar_slot(70, nil); ]] --
end

commands.add_command("load-quickbar", "Pre-load quickbar shortcuts",
                     function(command)
    local player = game.players[command.player_index]
    local target_player = player

    if (command.parameter ~= nil) then
        target_player = game.players[command.parameter]
    end

    command.load_quickbar(target_player)
end)

-- ########################################################

function command.Modules(moduleInventory) -- returns the multiplier of the modules
    local effect1 = moduleInventory.get_item_count("productivity-module") -- type 1
    local effect2 = moduleInventory.get_item_count("productivity-module-2") -- type 2
    local effect3 = moduleInventory.get_item_count("productivity-module-3") -- type 3

    local multi = effect1 * 4 + effect2 * 6 + effect3 * 10
    return multi / 100 + 1
end

function command.AmountOfMachines(itemsPerSecond, output)
    if (itemsPerSecond) then return itemsPerSecond / output end
end

commands.add_command("ratio",
                     "gives ratio info on the selected machine and its recipe. provide a number for items/sec",
                     function(command)
    local player = game.players[command.player_index]
    local machine = player.selected -- selected machine
    local itemsPerSecond
    if not machine then -- nil check
        return player.print(color.text.red("No valid machine selected.."))
    end

    if machine.type ~= "assembling-machine" and machine.type ~= "furnace" then
        return player.print(color.text.red("Invalid machine.."))
    end
    local recipe = machine.get_recipe() -- recipe

    if not recipe then -- nil check
        return player.print(color.text.red("No recipe set.."))
    end

    local items = recipe.ingredients -- items in that recipe
    local products = recipe.products -- output items
    local amountOfMachines
    local moduleInventory = machine.get_module_inventory() -- the module Inventory of the machine
    local multi = command.Modules(moduleInventory) -- function for the productively modules
    if (command.parameter ~= nil) then
        itemsPerSecond = tonumber(command.parameter)
    end
    if itemsPerSecond then
        amountOfMachines = math.ceil(command.AmountOfMachines(itemsPerSecond,
                                                              1 / recipe.energy *
                                                                  machine.crafting_speed *
                                                                  products[1]
                                                                      .amount *
                                                                  multi)) -- amount of machines
    end
    if not amountOfMachines then
        amountOfMachines = 1 -- set to 1 to make it not nil
    end
    ----------------------------items----------------------------
    for i, item in ipairs(items) do
        local sprite -- string to make the icon work either fluid ore item

        if item.type == "item" then
            sprite = 'ratio.item-in'
        else
            sprite = 'ratio.fluid-in'
        end

        local ips = item.amount / recipe.energy * machine.crafting_speed *
                        amountOfMachines -- math on the items/fluids per second
        player.print {sprite, math.round(ips, 3), item.name} -- full string
    end
    ----------------------------products----------------------------

    for i, product in ipairs(products) do
        local sprite -- string to make the icon work either fluid ore item

        if product.type == "item" then
            sprite = 'ratio.item-out'
        else
            sprite = 'ratio.fluid-out'
        end

        local output = 1 / recipe.energy * machine.crafting_speed *
                           product.amount * multi -- math on the outputs per second
        player.print {
            sprite, math.round(output * amountOfMachines, 3), product.name
        } -- full string

    end

    if amountOfMachines ~= 1 then
        player.print {'ratio.machines', amountOfMachines}
    end

end)

-- ##########################################

function command.GivePowerArmor(player)
    player.insert {name = "power-armor-mk2", count = 1}

    if player and player.get_inventory(defines.inventory.character_armor) ~= nil and
        player.get_inventory(defines.inventory.character_armor)[1] ~= nil then
        local p_armor =
            player.get_inventory(defines.inventory.character_armor)[1].grid
        if p_armor ~= nil then
            p_armor.put({name = "fusion-reactor-equipment"})
            p_armor.put({name = "fusion-reactor-equipment"})
            p_armor.put({name = "battery-mk2-equipment"})
            p_armor.put({name = "battery-mk2-equipment"})
            p_armor.put({name = "battery-mk2-equipment"})
            p_armor.put({name = "battery-mk2-equipment"})
            p_armor.put({name = "exoskeleton-equipment"})
            p_armor.put({name = "exoskeleton-equipment"})
            p_armor.put({name = "personal-roboport-mk2-equipment"})
            p_armor.put({name = "personal-roboport-mk2-equipment"})
            p_armor.put({name = "battery-mk2-equipment"})
            p_armor.put({name = "battery-mk2-equipment"})
            p_armor.put({name = "personal-roboport-mk2-equipment"})
            p_armor.put({name = "personal-roboport-mk2-equipment"})
            p_armor.put({name = "battery-mk2-equipment"})
            p_armor.put({name = "battery-mk2-equipment"})
        end
        player.insert {name = "construction-robot", count = 100}
        player.insert {name = "belt-immunity-equipment", count = 1}
    end
end

commands.add_command("give-power-armor", "gives you a power armor",
                     function(command)
    local player = game.players[command.player_index]

    local target_player = player
    if (command.parameter ~= nil) then
        target_player = game.players[command.parameter]
    end

    command.GivePowerArmor(target_player)
end)

-- #########################################

command.loaders_technology_map = {
    ['logistics'] = 'loader',
    ['logistics-2'] = 'fast-loader',
    ['logistics-3'] = 'express-loader'
}

function command.EnableLoaders(event)
    local research = event.research
    local recipe = command.loaders_technology_map[research.name]
    if recipe then
        research.force.recipes[recipe].enabled = true
        pcall(function()
            research.force.recipes[recipe].hidden_from_player_crafting = false
        end)
    end
end

-- #################################################

function command.give_starter_items(player)
    local items = config.start_items.normal.items
    for each, item in pairs(items) do
        player.insert {name = item.name, count = item.count}
    end
end

commands.add_command("give-starter-items", "gives player starter items",
function(command)
    local player = game.players[command.player_index]
    
    local target_player = player
    if (command.parameter ~= nil) then
        target_player = game.players[command.parameter]
    end
    
    command.give_starter_items(target_player)
end)

-- #################################################

--[[
    pointer stuff
]]

local function get_pointer(command)
    local player = game.players[command.player_index]
    if pointer and not command.parameter then return pointer end
    if not pointer or not pointer.x and not pointer.y then
        pointer = position:new(player.position)
    end
    if command.parameter ~= nil then
        local newpos = command.parameter
        newpos.x = newpos.x or newpos[1]
        newpos.y = newpos.y or newpos[2]
        pointer:set(newpos)
    end
    return pointer
end

commands.add_command("get_pointer",
                     "returns the pointer position. if no pointer exists, this command will create a new one at the given position.\nif no position is given, your character's position will be used.",
                     function(command) pointer = get_pointer(command) end)

commands.add_command("show_pointer",
                     "shows the pointer marker if pointer exists",
                     function(command)
    pointer = get_pointer(command)
    if not pointer.marker then
        pointer.marker = rendering.draw_rectangle {
            color = color.dark_orchid,
            filled = true,
            left_top = pointer,
            right_bottom = {x = pointer.x + 1, y = pointer.y + 1},
            surface = game.players[command.player_index].surface or
                game.surfaces[1],
            draw_on_ground = false,
            only_in_alt_mode = false
        }
    end
end)

commands.add_command("pointer_to_area",
                     "create a custom area object at the pointer position.\nif no pointer exists, this command will create a new one at the given position.\nif no position is given, your character's position will be used.",
                     function(command)
    if pointer.marker then
        rendering.set_time_to_live(pointer.marker, 360)
        if not renders_fadeout then renders_fadeout = {} end
        table.insert(renders_fadeout, pointer.marker)
    end
    pointer = get_pointer(command)
    pointer_area = area:from_position(pointer)
end)

commands.add_command("fill_area",
                     "use with a tile name to set the tiles inside the area pointer\nif no pointer area exists, you can create one with /pointer_to_area",
                     function(command)
    local player = game.players[command.player_index]
    local surface = player.surface
    if not command.parameter or not game.tile_prototypes[command.parameter] then
        player.print("invalid tile name")
        return
    end
    surface.set_tiles(pointer_area:fill_tile(command.parameter))
end)

commands.add_command("circle_area",
                     "use with a tile name to create a circle of tiles centered and contained withinin the area pointer",
                     function(command)
    local player = game.players[command.player_index]
    local surface = player.surface
    if not command.parameter or not game.tile_prototypes[command.parameter] then
        player.print("invalid tile name")
        return
    end
    surface.set_tiles(pointer_area:fill_inner_circle(command.parameter))
end)

commands.add_command("clear_pointer", "clears the pointer marker if one exists",
                     function(command)
    if pointer and pointer.marker then
        if not renders_fadeout then renders_fadeout = {} end
        rendering.set_time_to_live(pointer.marker, 360)
        table.insert(renders_fadeout, pointer.marker)
    else
        return
    end
end)

commands.add_command("clear_pointer_area",
                     "clears the pointer area marker if one exists",
                     function(command)
    if pointer_area and pointer_area.marker then
        if not renders_fadeout then renders_fadeout = {} end
        rendering.set_time_to_live(pointer_area.marker, 360)
        table.insert(renders_fadeout, pointer_area.marker)
    else
        return
    end
end)

commands.add_command("clear_pointer_and_area",
                     "clears both the pointer marker and pointer area marker if either exists",
                     function(command)
    if pointer and pointer.marker then
        if rendering.is_valid(pointer.marker) then
            if not renders_fadeout then renders_fadeout = {} end
            rendering.set_time_to_live(pointer.marker, 360)
            table.insert(renders_fadeout, pointer.marker)
        else
            return
        end
    else
        return
    end
    if pointer_area and pointer_area.marker then
        if rendering.is_valid(pointer_area.marker) then
            if not renders_fadeout then renders_fadeout = {} end
            rendering.set_time_to_live(pointer_area.marker, 360)
            table.insert(renders_fadeout, pointer_area.marker)
        else
            return
        end
    else
        return
    end
end)

return command
