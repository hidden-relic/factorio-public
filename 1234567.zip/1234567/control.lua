local rift = require('utils.rift')
local command = require('utils.commands')
local recharge = require('utils.recharge')
local config = require('utils.config')
local todo_gui = require('utils.todo_gui')

require('utils.raw')

require('utils.position')
require('utils.area')
require('utils.tools')
-- ----------------------------------------------------------------------------------------------------------------------
local event = require("flib.event")
local gui = require("flib.gui")
local mod_gui = require("__core__.lualib.mod-gui")
local table = require("flib.table")

-- EVENT HANDLERS

event.on_init(function()
    global.players = {}
    rift.init()
end)

event.on_tick(function(event)
    if (game.tick % 10) then
        rift.deposit_all()
        rift.tally_requests()
        rift.distribute_requests()
        rift.reload_turrets(rift.turrets)
        -- rift.check_belts()
        recharge.on_tick()
    end
    -- tools.fade_renderings()
    -- not functioning correctly just yet
end)

event.on_research_finished(function(e) command.EnableLoaders(e) end)

event.on_player_created(function(e)
    -- Create player table
    global.players[e.player_index] = {}
    local player_table = global.players[e.player_index]

    local player = game.get_player(e.player_index)

    -- CREATE GUIS

    gui.add(mod_gui.get_button_flow(player), {
        type = "sprite-button",
        style = mod_gui.button_style,
        sprite = "entity/logistic-chest-buffer",
        hovered_sprite = "entity/logistic-chest-buffer",
        clicked_sprite = "entity/logistic-chest-buffer",
        mouse_button_filter = {"left"},
        actions = {
            on_click = "toggle_global_pool_gui"
        }
    })
    gui.add(mod_gui.get_button_flow(player), {
        type = "sprite-button",
          style = mod_gui.button_style,
          sprite = "utility/list_view",
          hovered_sprite = "utility/list_view",
          clicked_sprite = "utility/list_view",
          mouse_button_filter = {"left"},
          actions = {
            on_click = "toggle_todo_gui"
          }
    })

    todo_gui.build(player, player_table)
    player_table.todo.refs.window.visible = false
    todo_gui.close(e)

    rift.global_pool_gui.build(player, player_table)
    player_table.global_pool_gui.refs.window.visible = false
    rift.global_pool_gui.close(e)
    -- --------------------------------------------------------------------
    local surface = player.surface
    if config.research_queue.toggled then
        player.force.research_queue_enabled = true
    end

    if config.power_armor.toggled then
        if config.power_armor.admin_only and player.admin then
            command.GivePowerArmor(player)
        end
        if not config.power_armor.admin_only then
            command.give_power_armor(player)
        end
    end

    if config.load_quickbar.toggled then
        if config.load_quickbar.admin_only and player.admin then
            command.load_quickbar(player)
        end
        if not config.load_quickbar.admin_only then
            command.load_quickbar(player)
        end
    end

    if config.robot_boost.toggled then
        player.force.worker_robots_speed_modifier = config.robot_boost.speed
        player.force.worker_robots_battery_modifier = config.robot_boost.battery
        player.force.worker_robots_storage_bonus = config.robot_boost.storage
    end

    if config.cheat_mode.toggled then
        if config.cheat_mode.admin_only and player.admin then
            player.cheat_mode = true
        end
        if not config.cheat_mode.admin_only then player.cheat_mode = true end
    end

    if config.start_items.toggled then
        for each, item in pairs(config.start_items.normal.items) do
            player.insert {
                    name = item.name,
                    count = item.count
                }
        end
        if config.start_items.cheaty.toggled then
            if config.start_items.cheaty.admin_only then
                if player.admin then
                    for each, item in pairs(command.quick_bar) do
                        player.insert {
                            name = item,
                            count = game.item_prototypes[item].stack_size
                        }
                    end
                else 
                    return
                end
            else
                for each, item in pairs(command.quick_bar) do
                    player.insert {
                        name = item,
                        count = game.item_prototypes[item].stack_size
                    }
                end
            end
        end
    end
end)

local function toggle_todo_gui(e)
    local player_table = global.players[e.player_index]
    local visible = player_table.todo.refs.window.visible
    if visible then
        todo_gui.close(e)
    else
        todo_gui.open(e)
    end
end

local function toggle_global_pool_gui(e)
    local player_table = global.players[e.player_index]
    local visible = player_table.global_pool_gui.refs.window.visible
    if visible then
        rift.global_pool_gui.close(e)
    else
        rift.global_pool_gui.update(e)
        rift.global_pool_gui.open(e)
    end
end

gui.hook_events(function(e)
    local action = gui.read_action(e)
    if action then
        if action == "toggle_todo_gui" then
            toggle_todo_gui(e)
        elseif action == "toggle_global_pool_gui" then
            toggle_global_pool_gui(e)
        elseif action == "close_global_pool_gui" then
            rift.global_pool_gui.close(e)
        else
            todo_gui.actions[action](e)
        end
    end
end)
